<?php

include("connection.php"); 

	$product_id = $_POST['product_id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
	$price = $_POST['price'];
	$image = $_POST['image'];
	
	if ($image != null){ //upload product without image
		
		uploadImage($pdo, $product_id, $name, $description, $price, $image);
		
	}else{ //upload product without image
				
		insertProduct($pdo, $product_id, $name, $description, $price);
	}



function uploadImage($pdo, $product_id, $name, $description, $price, $image){
	
	 //Query for get the last image id 
    $sql = "SELECT COUNT(*) FROM product";
    $statement = $pdo->prepare($sql);     
    $statement->execute();   
	$id = null; 
    $row = $statement->fetch(); 
	$id = $row[0] + 1;  
	
	//define image´s path
    $imagen = null;
	$path = "images/$id.png"; 
	$url = "https://www.moimah.com/gluonfx/uploads/$path"; 


	//get image, decode and upload to server	  
	 file_put_contents($path,base64_decode($image));  
	
	//call function to upload with the url
	insertProductWithUrl($pdo, $product_id, $name, $description, $price, $url);
 
}


function insertProduct($pdo, $product_id, $name, $description, $price){
			
		$sql = "INSERT INTO product(product_id, name, description, price) VALUES (?, ?, ?, ?)";
		$stmt= $pdo->prepare($sql);			
		$stmt->execute([$product_id, $name, $description, $price]);

}

function insertProductWithUrl($pdo, $product_id, $name, $description, $price, $url){
	
		$sql = "INSERT INTO product(product_id, name, description, price, url) VALUES (?, ?, ?, ?, ?)";
		$stmt= $pdo->prepare($sql);			
		$stmt->execute([$product_id, $name, $description, $price, $url]);
}


?>